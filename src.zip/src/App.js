import logo from './logo.svg';
import './App.css';
import { createContext,useState } from 'react';
import Addtask from './Components/Addtask';


const myfirstcontext = createContext();

function App() {
  const[task,settask] = useState();
  const[filldata,setfilldata] = useState('');

  const addtask = ()=>{
    settask(<Addtask />)
  }
  return (
    <myfirstcontext.Provider >
    <div className="App">
      <div className='Add_task'>
        <h3>Add a new Task</h3>
        <button onClick={addtask}>Add Task</button>
        {task}
      </div>
      <div className='view_task'>
       <h3>View the task </h3>
       <button >View Task</button>
      </div>
    </div>
    </myfirstcontext.Provider>
  );
}

export default App;
