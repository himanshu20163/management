import React, { useContext, useState } from 'react'
import { myfirstcontext } from '../App';
import Update from './Update';
import './view.css'

const View = () => {
  const {Alldata,setalladata} = useContext(myfirstcontext);
  const [update,setupdate] = useState();

  const delete_box = (e)=>{
    let ans = Alldata.filter((ele, id) => {
      return  id != e  ;
    })
    setalladata(ans);
    console.log(Alldata);
  }

  const update_box = (e) =>{
    return(
      <div>
        <h1>{e}</h1>
      </div>
    )
    console.log(e); 
  }

  const markdata = (e)=>{
    alert(e.target.checked);
  }

  return (
    <div>
      {Alldata.map((e,i)=>{
      return (<div>
        <div className="view_box" key={i} ><p style={{width:"90px"}}>{e.title}</p><p style={{width:"90px"}}>{e.desc}</p>
        <input type='checkbox' id="mark" onClick={markdata} checked="checked"></input>
        <input type='button' id="btn_updt" value='Update' onClick={()=>{
            setupdate(<Update userkey={i} />)
          }} />
          {update}
        <input type='button' id="btn_del" value="Delete" onClick={ () => delete_box(i) }/>
        </div>
      </div>)
    })}
    {/* <p>himanshu</p> */}
    </div>
  )
}

export default View